"""
UCSF BMI203: Biocomputing Algorithms
Author:
Date:
Package: 
Description: 
"""
import numpy as np
from .hmm import *

__version__ = '0.1.0'